<?php

namespace App\Http\Controllers\Wallpaper;

use App\Http\Resources\Wallpaper as ResourcesWallpaper;
use App\Http\Resources\WallpaperCollection;
use App\Models\Tag;
use App\Models\Wallpaper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;


class WallpaperController extends BaseController
{
    public function index()
    {
        $data = new WallpaperCollection(Wallpaper::cursorPaginate($this->perPage));
        // return Response::json($data, 200);

        return $this->sendResponse($data, 'Posts fetched.');
    }
    public function showByTag(Tag $tag)
    {
        $wallpapers = $tag->wallpapers();
        $data = new WallpaperCollection($wallpapers->cursorPaginate($this->perPage));
        // return Response::json($data, 200);

        return $this->sendResponse($data, 'Posts fetched.');
    }


    public function store(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'title' => 'required',
            'description' => 'required'
        ]);
        if ($validator->fails()) {
            return $this->sendError($validator->errors());
        }
        $wallpaper = Wallpaper::create($input);
        return $this->sendResponse(new ResourcesWallpaper($wallpaper), 'Post created.');
    }


    public function show($id)
    {
        $wallpaper = Wallpaper::find($id);
        if (is_null($wallpaper)) {
            return $this->sendError('Post does not exist.');
        }
        return $this->sendResponse(new ResourcesWallpaper($wallpaper), 'Post fetched.');
    }


    public function update(Request $request, Wallpaper $wallpaper)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'title' => 'required',
            'description' => 'required'
        ]);

        if ($validator->fails()) {
            return $this->sendError($validator->errors());
        }

        $wallpaper->title = $input['title'];
        $wallpaper->description = $input['description'];
        $wallpaper->save();

        return $this->sendResponse(new ResourcesWallpaper($wallpaper), 'Post updated.');
    }

    public function destroy(Wallpaper $wallpaper)
    {
        $wallpaper->delete();
        return $this->sendResponse([], 'Post deleted.');
    }
}
