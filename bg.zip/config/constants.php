<?php
//wallpaper manager
define('ROLE_WP_MANAGER',10);